## 19,000 words

They say, "a picture is worth one thousand words."

The following 19 slides show what really happens when we run:

```bash
kubectl create deployment web --image=nginx
```

---
class: pic
![](images/kubectl-create-deployment-slideshow/01.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/02.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/03.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/04.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/05.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/06.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/07.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/08.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/09.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/10.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/11.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/12.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/13.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/14.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/15.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/16.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/17.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/18.svg)
---
class: pic
![](images/kubectl-create-deployment-slideshow/19.svg)
