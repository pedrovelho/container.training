## Exercise — Application Configuration

- Configure an application with a ConfigMap

- Generate configuration file from the downward API
