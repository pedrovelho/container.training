## Exercise — Umbrella Charts

- Create a Helm chart with dependencies on other charts

  (leveraging the generic chart created earlier)

- Deploy dockercoins with that chart

- Bonus: use an external chart for the redis component
