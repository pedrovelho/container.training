# Building containers from scratch

(This is a "bonus section" done if time permits.)