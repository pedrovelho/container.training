## Clean up

- Before moving on, let's remove those containers

.lab[

- Tell Compose to remove everything:
  ```bash
  docker-compose down
  ```

]
